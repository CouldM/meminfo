import numpy as np
import matplotlib.pyplot as plt
import xlrd
import xlutils.copy

workbook = xlrd.open_workbook("performence_info.xls")
wb = xlutils.copy.copy(workbook)
report_sheet = wb.add_sheet("report")

def mem(packagename):
    filename = packagename
    invaild_char = '\\/:*?<>"|'
    for i in invaild_char:
        filename = filename.replace(i,"_")

    mysheet = workbook.sheet_by_name('%s_m' % filename)

    N = mysheet.col_values(0)
    del N[0]
    x = []
    for i in N:
        x.append(int(i))
    J = mysheet.col_values(1)
    del J[0]
    y1 = []
    for i in J:
        y1.append(int(i))
    Na = mysheet.col_values(2)
    del Na[0]
    y2 = []
    for i in Na:
        y2.append(int(i))
    T = mysheet.col_values(3)
    del T[0]
    y3 = []
    for i in T:
        y3.append(int(i))

    line_1 = plt.plot(x,y1,linestyle = '-',linewidth = 2,label = 'Java_Heap',color = 'b')
    line_2 = plt.plot(x,y2,linestyle = '-',linewidth = 2,label = 'Native_Heap',color = 'r')
    line_3 = plt.plot(x,y3,linestyle = '-',linewidth = 2,label = 'Total',color = 'y')

    plt.title('%s-mem(M)' % packagename)
    plt.legend()
    chart = plt.show()
    wb.add_chart(chart)
    wb.save("performence_info.xls")
    pass

mem("com.miui.systemAdSolution")
